# Fundamentos Java Script

Sites - Aplicativos - Sistemas
Aplica Camada Logica

- Estado JS ( stateofjs.com).
- Onde e executado.
- Onipresente na Web.
- App Hibridos.
- Aplicação de ponta a ponta, banco de dados : Back-End, Front-End.
- Interação com DOM - API WEB.
- Requisições dinamicas.
- IoT (Internet das coisas). JS esta presente em tudo.
- Fundamentos do JavaScript são essenciais para avançar no desenvolvimento de aplicações modernas, é a base de diversos frameworks.
- Evoluimos da base para o topo.
- Melhor que começar na frente e precisa retornas a base.

## Metodologia

- Método progressivo e integrado.
- Todod arranha ceu so é erguido depois de ter uma fundação robusta e segura.
- Neste curso apresentamos conceitos de modo progressivo, seguindo uma linha de evolução.
- Começa facil e vai aumentando a complexidade.
- Alem de especialização, aprendemos a interagir com diversas possibilidades.

## Logica de Programação

- Computador : Maquina que extrai dados.
- Processar : Realizar operações nos dados de entrada.
- Dado : É o que  pode ser processado.
- Informação : Resultado do processamento.
- Processamento de dados : Entrada ( Dado ) > Processamento > Saída ( Informação ).

- Logica ?
-- É o que faz sentido

- Como escrever um programa.
-- Aplicar a logica par descrever os passos, para resolver um problema em ordem de execução.

-Logica de Programação :
-- É a tecnica de sequenciar pensamentos, passos, fluxos de dados para  atingir um objetivo : a informação.
-- A sequência de passos, instruções que o computador deve seguir e conhecida como ALGORITIMO.

## Algoritmo

- Sequência Logica e finita de instruções que resolvem um problema.
Exemplo
